"""plugin://script.freemytv/?copy=<reload>: the first tab's copy (resources/lib/first.py), served at once at start.
Only what Python has at hand: at start every import waits its turn.
"""
import json
import sys

import xbmcgui
import xbmcplugin
import xbmcvfs

handle = int(sys.argv[1])
try:
    with open(xbmcvfs.translatePath('special://profile/addon_data/script.freemytv/first.json'), encoding='utf-8') as f:
        items = json.load(f).get('items', [])
except (OSError, ValueError):
    items = []
out = []
for o in items:
    item = xbmcgui.ListItem(o['Label'], offscreen=True)
    item.setArt({k: o['Art(%s)' % k] for k in ('poster', 'thumb', 'tvshow.poster', 'fanart') if o.get('Art(%s)' % k)})
    tag = item.getVideoInfoTag()
    tag.setTitle(o['Label'])
    tag.setPlot(o['Plot'])
    tag.setMpaa(o['Mpaa'])
    tag.setGenres([g for g in o['Genre'].split(' / ') if g])
    tag.setTags([t for t in o['Tag'].split(' / ') if t])
    if o['Year'].isdigit():
        tag.setYear(int(o['Year']))
    try:
        tag.setRating(float(o['Rating'].replace(',', '.')), 0, 'imdb', True)
    except ValueError:
        pass
    for name in ('ItemType', 'id', 'later'):
        if o.get('Property(%s)' % name):
            item.setProperty(name, o['Property(%s)' % name])
    item.setProperty('fmt_copy', 'true')   # first.keep waits for JellyCon's own items
    out.append((o['FileNameAndPath'], item, o.get('folder', False)))
xbmcplugin.addDirectoryItems(handle, out, len(out))
xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
