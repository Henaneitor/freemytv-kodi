"""Where Home's panel puts the focused title's facts (Película · 2001 · 122 min · …): on the title's line, at its right
end, and when they don't fit next to the title, in the room the title leaves, moving so they can be read whole. Kodi
can't measure a label, so the service measures both with the skin's fonts (ttf.py) as the focus moves, and Home reads
fmt_panel_at: empty when they fit, else the x where they start (a step of the skin's FMT_PanelFacts)."""
import math
import time

import xbmc
import xbmcgui
import xbmcvfs

import ttf

HOME = xbmcgui.Window(10000)
# The panel's fonts and sizes (install.py's FONTS: fmt_paneltitle, fmt_facts) and places (Home.xml, install.py's
# PANEL_STEP): the title starts at 26 and scrolls past TITLE_MAX; the facts end at 1734, or 1496 by the woke pill
TITLE_FONT, TITLE_SIZE, FACTS_FONT, FACTS_SIZE = 'Inter-Display-SemiBold.ttf', 42, 'Inter-Text-Medium.ttf', 28
# The synopsis (fmt_plot, Home's textbox: 1708 wide, 3 lines) and its autoscroll: 5 s, then 4 s a line, 10 s at the end
PLOT_FONT, PLOT_SIZE, PLOT_W, PLOT_LINES, DELAY, LINE, HOLD = 'Inter-Text-Regular.ttf', 30, 1708, 3, 5, 4, 10
LEFT, TITLE_MAX, GAP, STEP, END, END_WOKE = 26, 1000, 44, 25, 1734, 1496
ITEM = 'Container(9100).ListItem.'
KINDS = {'Movie': 'Película', 'Episode': 'Episodio'}


def facts():
    """The facts as the skin writes them (install.py's FMT_Kind and FMT_Facts)."""
    get = lambda name: xbmc.getInfoLabel(ITEM + name)
    kind = get('Property(ItemType)')
    if kind == 'Series':
        seasons = get('Property(TotalSeasons)')
        first = 'Serie' + ('  ·  1 temporada' if seasons == '1' else '  ·  %s temporadas' % seasons if seasons.isdigit() and int(seasons) > 1 else '')
    else:
        first = KINDS.get(kind, '')
    minutes = get('Duration(mins)')
    rating = get('Rating')
    parts = [first + ('  ·  ' if first else '') + get('Year'), minutes and minutes + ' min', get('Genre'),
             rating and rating + '/10', get('Mpaa')]
    return '  ·  '.join(p for p in parts if p)


def lines(text, ems):
    """How many lines the synopsis takes in Home's textbox (words wrapped as Kodi does, near enough)."""
    count, line = 0, ''
    for paragraph in text.split('\n'):
        count += 1
        line = ''
        for word in paragraph.split(' '):
            wider = (line + ' ' + word) if line else word
            if line and ttf.width(wider, ems, PLOT_SIZE) > PLOT_W:
                count += 1
                wider = word
            line = wider
    return count


def show(name, on):
    if bool(HOME.getProperty(name)) != on:
        HOME.setProperty(name, 'true') if on else HOME.clearProperty(name)


def place(title_ems, facts_ems):
    title = xbmc.getInfoLabel(ITEM + 'Label')
    end = END_WOKE if 'woke:' in xbmc.getInfoLabel(ITEM + 'Tag') else END
    show('fmt_title_long', ttf.width(title, title_ems, TITLE_SIZE) > TITLE_MAX)
    title_w = min(ttf.width(title, title_ems, TITLE_SIZE), TITLE_MAX)
    if LEFT + title_w + GAP + ttf.width(facts(), facts_ems, FACTS_SIZE) <= end:
        HOME.clearProperty('fmt_panel_at')
    else:   # in the room after the title, a step of the skin's
        HOME.setProperty('fmt_panel_at', str(int(math.ceil((LEFT + title_w + GAP) / STEP) * STEP)))


def watch(monitor):
    """As the focus moves on Home, the facts' place for the title now focused."""
    fonts = xbmcvfs.translatePath('special://skin/fonts/')
    try:
        title_ems, facts_ems = ttf.advances(fonts + TITLE_FONT), ttf.advances(fonts + FACTS_FONT)
        plot_ems = ttf.advances(fonts + PLOT_FONT)
    except (OSError, ValueError, KeyError, TypeError) as e:   # another skin, or a font changed: facts on the right always
        xbmc.log('Free My TV, panel: %s' % e, xbmc.LOGWARNING)
        return
    last, since, extra = None, 0, 0
    while not monitor.waitForAbort(0.1):
        if not xbmc.getCondVisibility('Window.IsVisible(home)'):
            continue
        now = xbmc.getInfoLabel(ITEM + 'Property(id)') + xbmc.getInfoLabel(ITEM + 'Label')
        # With a dialog over Home (the spinner as a title starts, JellyCon's menu) Home's list reads empty: as it was
        if not now or not xbmc.getCondVisibility('Window.IsActive(home)'):
            continue
        if now != last:
            last, since = now, time.time()
            place(title_ems, facts_ems)
            extra = max(0, lines(xbmc.getInfoLabel(ITEM + 'Plot'), plot_ems) - PLOT_LINES)
        # Where the textbox's rise is: more below until its end; risen from its first line up to when it starts again
        at = (time.time() - since) % (DELAY + extra * LINE + HOLD) if extra else 0
        show('fmt_plot_more', extra > 0 and at < DELAY + extra * LINE - 0.3)
        show('fmt_plot_top', extra > 0 and DELAY + 0.4 < at < DELAY + extra * LINE + HOLD - 0.2)
