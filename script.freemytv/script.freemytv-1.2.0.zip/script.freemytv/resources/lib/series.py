"""A series' page (script-freemytv-series.xml): its backdrop, title, facts and synopsis, Continue Watching and Watch
Later, the seasons as pills and each season's episodes as a row of stills, the focused one's synopsis below. OK on an
episode plays it through JellyCon.
"""
import threading

import xbmc
import xbmcgui

import jellyfin
import later

PLAY, LATER, SEASONS, EPISODES = 600, 601, 400, 500
BACK = (9, 10, 92)
MOVE = (1, 2)   # left, right: another season may have the focus


def woke(tags):
    """The woke tag's label and colour, as on the TV (Jellyfin.wokeLabel / wokeColor); none without the tag."""
    tag = next((t[5:].strip() for t in tags if t.lower().startswith('woke:')), None)
    if tag is None:
        return '', 'FF8E8E93'
    colours = ['FF2FB24C', 'FF6CBF3A', 'FFD9C23A', 'FFE8A934', 'FFEC8A2F', 'FFE5352B', 'FFD0275A', 'FFB8278A',
               'FF8E2BB0', 'FF5E2AA8']
    try:
        level = int(''.join(c for c in tag.split('-')[0] if c.isdigit()))
    except ValueError:
        return 'Woke: ' + tag.replace('-', ' '), 'FF8E8E93'
    return 'Woke ' + tag, 'FF0A84FF' if level == 0 else colours[min(9, level // 10)]


def minutes(ticks):
    m = int((ticks or 0) / 600000000)
    return '%d h %02d min' % (m // 60, m % 60) if m >= 60 else '%d min' % m if m else ''


class Series(xbmcgui.WindowXMLDialog):
    series_id = ''
    chosen = None   # the episode to play once the window is closed
    seasons = []
    season = -1
    next_up = None

    def onInit(self):
        s = jellyfin.call('/Users/{user}/Items/%s' % self.series_id)
        self.setProperty('title', s.get('Name', ''))
        facts = [str(s['ProductionYear'])] if s.get('ProductionYear') else []
        facts += s.get('Genres', [])[:2]
        if s.get('CommunityRating'):
            facts.append('★ %.1f' % s['CommunityRating'])
        if s.get('OfficialRating'):
            facts.append(s['OfficialRating'])
        self.setProperty('facts', '  ·  '.join(facts))
        label, colour = woke(s.get('Tags', []))
        self.setProperty('woke', label)
        self.setProperty('wokecolor', colour)
        self.setProperty('overview', s.get('Overview', ''))
        if s.get('BackdropImageTags'):
            self.setProperty('backdrop', jellyfin.image(self.series_id, 'Backdrop', 1920, s['BackdropImageTags'][0]))
        self.backdrop = self.getProperty('backdrop')
        self.refresh_later()

        self.seasons = jellyfin.call('/Shows/%s/Seasons?userId={user}&IsMissing=false' % self.series_id).get('Items', [])
        items = []
        for season in self.seasons:
            item = xbmcgui.ListItem(season.get('Name', ''))
            items.append(item)
        self.getControl(SEASONS).addItems(items)

        nxt = jellyfin.call('/Shows/NextUp?SeriesId=%s&UserId={user}&Limit=1' % self.series_id).get('Items', [])
        self.next_up = nxt[0] if nxt else None
        start = 0
        if self.next_up:
            ep = self.next_up
            self.setProperty('playlabel', 'Seguir viendo  ·  T%s:E%s' % (ep.get('ParentIndexNumber', '?'), ep.get('IndexNumber', '?')))
            start = next((i for i, x in enumerate(self.seasons) if x['Id'] == ep.get('SeasonId')), 0)
        else:
            self.setProperty('playlabel', 'Empezar')
        if self.seasons:
            self.getControl(SEASONS).selectItem(start)
            self.load(start)
        self.setFocusId(PLAY)

    def refresh_later(self):
        inside = self.series_id in later.ids()
        self.setProperty('laterlabel', 'En Ver más tarde' if inside else 'Ver más tarde')

    def load(self, index):
        """The season's episodes, in the row (the next one to watch focused when it's this season)."""
        if index == self.season or index >= len(self.seasons):
            return
        self.season = index
        seasons = self.getControl(SEASONS)
        for i in range(seasons.size()):   # the season on show: a lighter pill
            seasons.getListItem(i).setProperty('current', 'true' if i == index else '')
        season = self.seasons[index]
        episodes = jellyfin.call('/Shows/%s/Episodes?userId={user}&seasonId=%s&IsMissing=false&IsVirtualUnAired=false'
                                 '&Fields=Overview' % (self.series_id, season['Id'])).get('Items', [])
        items, focus = [], 0
        for i, ep in enumerate(episodes):
            item = xbmcgui.ListItem('%s. %s' % (ep.get('IndexNumber', i + 1), ep.get('Name', '')))
            tags = ep.get('ImageTags', {})
            still = jellyfin.image(ep['Id'], 'Primary', 640, tags['Primary']) if tags.get('Primary') else self.backdrop
            item.setArt({'thumb': still})
            data = ep.get('UserData', {})
            done = 100 if data.get('Played') else int(data.get('PlayedPercentage') or 0)
            item.setProperties({'id': ep['Id'], 'overview': ep.get('Overview', ''), 'runtime': minutes(ep.get('RunTimeTicks')),
                                'progress': str(min(10, (done + 5) // 10)) if done else '', 'played': 'true' if data.get('Played') else ''})
            items.append(item)
            if self.next_up and ep['Id'] == self.next_up['Id']:
                focus = i
        control = self.getControl(EPISODES)
        control.reset()
        control.addItems(items)
        if items:
            control.selectItem(focus)

    def onAction(self, action):
        if action.getId() in BACK:
            self.close()
        elif action.getId() in MOVE and self.getFocusId() == SEASONS:
            self.load(self.getControl(SEASONS).getSelectedPosition())

    def onClick(self, control):
        if control == SEASONS:
            self.load(self.getControl(SEASONS).getSelectedPosition())
            self.setFocusId(EPISODES)
        elif control == EPISODES:
            item = self.getControl(EPISODES).getSelectedItem()
            if item:
                self.chosen = item.getProperty('id')
                self.close()
        elif control == PLAY:
            if self.next_up:
                self.chosen = self.next_up['Id']
                self.close()
            elif self.getControl(EPISODES).size():
                self.chosen = self.getControl(EPISODES).getListItem(0).getProperty('id')
                self.close()
        elif control == LATER:
            added = later.toggle(self.series_id, self.getProperty('title'))
            self.setProperty('laterlabel', 'En Ver más tarde' if added else 'Ver más tarde')


def show(addon_path, series_id):
    window = Series('script-freemytv-series.xml', addon_path, 'Default', '1080i')
    window.series_id = series_id
    window.doModal()
    chosen = window.chosen
    del window
    if chosen:
        xbmc.executebuiltin('PlayMedia("%s",noresume)' % jellyfin.play(chosen))   # JellyCon asks about resuming
    return chosen   # the filters reopen only when nothing plays
