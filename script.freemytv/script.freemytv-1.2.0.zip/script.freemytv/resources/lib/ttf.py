"""How wide a text is in a TrueType font, from its glyphs' advances (cmap and hmtx), for the panel's layout: Kodi
can't measure a label. Kerning is left out, which is close enough for Inter."""
import struct


def advances(path):
    """{character: advance in ems} for the font's Basic Multilingual Plane (cmap format 4)."""
    data = open(path, 'rb').read()
    tables = {}
    for i in range(struct.unpack('>H', data[4:6])[0]):
        tag, _, offset, _ = struct.unpack('>4sIII', data[12 + 16 * i:28 + 16 * i])
        tables[tag.decode()] = offset
    upm = struct.unpack('>H', data[tables['head'] + 18:tables['head'] + 20])[0]
    metrics = struct.unpack('>H', data[tables['hhea'] + 34:tables['hhea'] + 36])[0]
    widths = struct.unpack('>%dH' % (2 * metrics), data[tables['hmtx']:tables['hmtx'] + 4 * metrics])[::2]
    cmap = tables['cmap']
    sub = None
    for i in range(struct.unpack('>H', data[cmap + 2:cmap + 4])[0]):
        platform, encoding, offset = struct.unpack('>HHI', data[cmap + 4 + 8 * i:cmap + 12 + 8 * i])
        if (platform, encoding) in ((3, 1), (0, 3)) and struct.unpack('>H', data[cmap + offset:cmap + offset + 2])[0] == 4:
            sub = cmap + offset
    segs = struct.unpack('>H', data[sub + 6:sub + 8])[0] // 2
    ends = struct.unpack('>%dH' % segs, data[sub + 14:sub + 14 + 2 * segs])
    starts = struct.unpack('>%dH' % segs, data[sub + 16 + 2 * segs:sub + 16 + 4 * segs])
    deltas = struct.unpack('>%dh' % segs, data[sub + 16 + 4 * segs:sub + 16 + 6 * segs])
    ranges_at = sub + 16 + 6 * segs
    ranges = struct.unpack('>%dH' % segs, data[ranges_at:ranges_at + 2 * segs])
    out = {}
    for s in range(segs):
        for code in range(starts[s], min(ends[s], 0x2FFF) + 1):
            if ranges[s]:
                at = ranges_at + 2 * s + ranges[s] + 2 * (code - starts[s])
                glyph = struct.unpack('>H', data[at:at + 2])[0]
                glyph = (glyph + deltas[s]) & 0xFFFF if glyph else 0
            else:
                glyph = (code + deltas[s]) & 0xFFFF
            if glyph:
                out[chr(code)] = widths[min(glyph, metrics - 1)] / upm
    return out


def width(text, ems, size):
    """The text's width in pixels at that size; an unknown character counts as an "n"."""
    return sum(ems.get(c, ems.get('n', 0.55)) for c in text) * size


if __name__ == '__main__':   # python3 ttf.py <font.ttf>: a few widths
    import sys
    ems = advances(sys.argv[1])
    for text in ('El Marqués 1985', 'Slow Horses', 'Serie  ·  1 temporada  ·  2026  ·  Drama  ·  16'):
        print(round(width(text, ems, 42)), round(width(text, ems, 28)), text)
